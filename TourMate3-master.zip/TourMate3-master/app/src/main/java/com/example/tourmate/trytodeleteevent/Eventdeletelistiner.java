package com.example.tourmate.trytodeleteevent;

public interface Eventdeletelistiner {
    void onDelete(String eventid);
}
